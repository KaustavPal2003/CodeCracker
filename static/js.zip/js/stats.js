// static/js/stats.js
document.addEventListener("DOMContentLoaded", () => {
    setTimeout(() => {
        document.getElementById("loading").style.display = "none";
        document.getElementById("stats-container").style.display = "block";
    }, 500); // Adjust timeout as needed
});